#include "systemc.h"
SC_MODULE(lk_counter)
{
	sc_in<sc_logic> clock,reset;
	sc_out<sc_uint<4> > count_out;

	sc_uint<4> count_buf;//as a middle variable or a buf ot a wire?

	void count()
		{
			if(reset.read()==1)
				{
					count_buf=0;
					count_out.write(0);
				}
			else
				{	
					count_buf=count_buf+1;
					count_out.write(count_buf);
				}
		}
	SC_CTOR(lk_counter)
		{
			SC_METHOD(count);
			sensitive<<reset;
			sensitive<<clock.pos();
		}
};//a new line
